# damage car  > v2
https://universe.roboflow.com/object-detection/damage-car

Provided by Roboflow
License: CC BY 4.0

